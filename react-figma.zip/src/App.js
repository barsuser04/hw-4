import "./App.css";
import Expenses from "./components/expenses/Expenses";
import NewExpense from "./components/new-expenses/NewExpense";


const expenses = [
  {
    title: 'Toilet paper',
    price: 300,
    date: new Date()
  },

  {
    title: 'Food',
    price: 400,
    date: new Date()
  }
]
function App() {
  return <div className="App">
    <NewExpense/>
    <Expenses expenses={expenses}/>
  </div>
}

export default App;
