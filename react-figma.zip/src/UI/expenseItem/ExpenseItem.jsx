import React from 'react';
import "./ExpenseItem.css"

const ExpenseItem = ({  date, title, price }) => {
    return (
        <div className='itemDiv'>
            <p>{date.toString()}</p>
            <p>{title}</p>
            <p>{price}</p>
        </div>
    );
};

export default ExpenseItem;