import React from "react";
import Button from "../../UI/button/Button";
import FormInput from "../../UI/formInput/FormInput";

const ExpenseForm = (props) => {
  const cancelHandler = (e) => {
    e.preventDefault();
    props.onSwowForm();
  };
  return (
    <form>
      <FormInput
        id="name"
        labelName="Название"
        inputType="text"
        placeholder="Введите название"
      />

      <FormInput labelName="Количество денег" inputType="number" id="money" />

      <FormInput
        labelName="Date"
        inputType="date"
        placeholder="дд.мм.гггг"
        id="date"
      />

      <Button title="Отмена"/>
      <Button title="Сохранить" onClick={cancelHandler}  />
    </form>
  );
};

export default ExpenseForm;
